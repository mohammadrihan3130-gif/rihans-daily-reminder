package com.rihan.dailyreminder

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Calendar

private data class Task(val id: Int, val title: String, val time: String, val quote: String)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("rihan_daily_reminder", MODE_PRIVATE) }
    private lateinit var list: LinearLayout
    private lateinit var progress: TextView
    private val tasks = listOf(
        Task(1, "Wake up", "08:00", "Win the morning, and take the first step toward winning the day."),
        Task(2, "Fajr / daily Namaz", "05:00", "Strengthen your connection with Allah, and let faith guide your steps."),
        Task(3, "Dhuhr Namaz", "13:00", "Pause, be grateful, and return to your day with purpose."),
        Task(4, "Asr Namaz", "16:00", "Consistency in small acts builds a stronger heart."),
        Task(5, "Maghrib Namaz", "18:15", "Make space for what matters most."),
        Task(6, "Isha Namaz", "20:00", "End your day with gratitude and faith."),
        Task(7, "Workout (30–60 minutes)", "17:00", "Discipline is choosing what you want most over what you want now."),
        Task(8, "Social media limit (1–2 hours total)", "12:00", "Control your attention, or someone else will."),
        Task(9, "Learn trading", "21:00", "Protect your capital, master your emotions, and learn before chasing profit."),
        Task(10, "Study / learn a useful skill", "15:00", "One hour of learning today can open doors tomorrow."),
        Task(11, "Drink water and personal hygiene", "08:10", "Respect yourself in the little things."),
        Task(12, "Review today and plan tomorrow", "22:15", "Don't aim to be perfect; aim to be better than yesterday."),
        Task(13, "Sleep wind-down — sleep before 11:30 PM", "22:45", "Rest is preparation for tomorrow's battles.")
    )
    private fun dayKey() = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
    private fun completed(id: Int) = prefs.getBoolean("${dayKey()}_$id", false)
    private fun setCompleted(id: Int, value: Boolean) { prefs.edit().putBoolean("${dayKey()}_$id", value).apply() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        resetForNewDay()
        createNotificationChannel()
        requestNotificationPermission()
        scheduleDailyReminders()
        buildScreen()
    }

    private fun resetForNewDay() {
        val last = prefs.getString("last_day", "")
        if (last != dayKey()) prefs.edit().putString("last_day", dayKey()).apply()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(11,17,32)) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(38, 34, 38, 32) }
        scroll.addView(root)
        val brand = text("RIHAN'S PERSONAL ROUTINE", 12, Color.rgb(140,224,181), true)
        root.addView(brand)
        root.addView(text("Daily Reminder.", 30, Color.WHITE, true).apply { setPadding(0, 8, 0, 4) })
        root.addView(text(java.text.SimpleDateFormat("EEEE, dd MMMM yyyy", java.util.Locale.getDefault()).format(java.util.Date()), 14, 0xFFA9B5C8.toInt(), false))
        progress = text("", 15, Color.WHITE, true).apply { setPadding(0, 24, 0, 12) }
        root.addView(progress)
        val info = text("Tick each activity when you finish it. Your checklist is saved on this phone and works offline.", 14, 0xFFA9B5C8.toInt(), false)
        root.addView(info)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 18, 0, 0) }
        root.addView(list)
        val reset = Button(this).apply { text = "Reset today's ticks"; setOnClickListener { tasks.forEach { setCompleted(it.id, false) }; renderTasks() } }
        root.addView(reset)
        val foot = text("Namaz reminder times are starter examples. Adjust them to your local prayer times in your daily routine; Android notification permissions and battery settings can affect delivery.", 12, 0xFFA9B5C8.toInt(), false)
        foot.setPadding(0, 18, 0, 0); root.addView(foot)
        setContentView(scroll)
        renderTasks()
    }

    private fun renderTasks() {
        list.removeAllViews()
        val done = tasks.count { completed(it.id) }
        progress.text = "TODAY'S PROGRESS   $done / ${tasks.size} completed (${done * 100 / tasks.size}%)"
        tasks.forEach { task ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 16)
                setBackgroundColor(if (completed(task.id)) Color.rgb(25, 53, 44) else Color.rgb(20, 30, 48))
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val check = CheckBox(this).apply {
                isChecked = completed(task.id); buttonTintList = android.content.res.ColorStateList.valueOf(0xFF8CE0B5.toInt())
                setOnCheckedChangeListener { _, checked -> setCompleted(task.id, checked); renderTasks() }
            }
            row.addView(check)
            val title = text(task.title, 16, Color.WHITE, true)
            row.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text(task.time, 13, 0xFF8CE0B5.toInt(), true))
            card.addView(row)
            card.addView(text("“${task.quote}”", 14, 0xFFD0D9E7.toInt(), false).apply { setPadding(8, 8, 8, 2) })
            val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 12
            list.addView(card, lp)
        }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("daily_tasks", "Daily task reminders", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 44)
        }
    }

    private fun scheduleDailyReminders() {
        val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        tasks.forEach { task ->
            val parts = task.time.split(":")
            val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, parts[0].toInt()); set(Calendar.MINUTE, parts[1].toInt()); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
            val intent = Intent(this, ReminderReceiver::class.java).putExtra("title", task.title).putExtra("quote", task.quote).putExtra("id", task.id)
            val pi = PendingIntent.getBroadcast(this, task.id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            try { if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) else alarm.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) } catch (_: Exception) { }
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val title = intent.getStringExtra("title") ?: "Daily reminder"
        val quote = intent.getStringExtra("quote") ?: "Keep going, one task at a time."
        val notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(context, "daily_tasks") else Notification.Builder(context)
        notification.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(title).setContentText(quote).setAutoCancel(true)
        manager.notify(intent.getIntExtra("id", 1), notification.build())
        // Schedule the next day's reminder for the same activity.
        val id = intent.getIntExtra("id", 1)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val next = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
        try { if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi) else alarm.set(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi) } catch (_: Exception) { }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val launch = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            // MainActivity reschedules reminders when opened; no activity is started automatically.
        }
    }
}
