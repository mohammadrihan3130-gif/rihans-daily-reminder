# Rihan's Daily Reminder

A simple native Android (Kotlin) starter project for an offline daily checklist with activity-specific motivational quotes and local reminder notifications.

## Build
1. Install Android Studio (free) on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle to sync and install any required Android SDK platform (API 35).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your Android phone and allow notification permission.

## Notes
- Tasks and daily checkmarks are stored locally using SharedPreferences.
- The Namaz times in this starter are example times; change them to match local prayer times before relying on them.
- Android may delay notifications due to battery optimization and permission settings. This is a source project, not a precompiled APK.
